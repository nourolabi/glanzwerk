# Glanzwerk Rheinland - Rechnungssystem

## Projektübersicht

**Projektname:** Glanzwerk Rheinland - Rechnungssystem  
**Typ:** Interaktive Webanwendung  
**Entwickler:** Mazen Design  
**Bereich:** Autowäscherei - Rechnungsgenerierung - Serviceverwaltung  
**Live-URL:** https://58hpi8c7n3dj.manus.space

## Projektbeschreibung

Das "Glanzwerk Rechnungssystem" ist ein intelligentes Rechnungssystem, das speziell für die Autowäscherei Glanzwerk Rheinland in Neuwied, Deutschland, entwickelt wurde. Das System automatisiert den Prozess der Rechnungserstellung und generiert professionelle PDF-Dateien, die sofort gedruckt und an Kunden übergeben werden können, über eine benutzerfreundliche browserbasierte Oberfläche.

## Hauptfunktionen

### ✅ Kernfunktionen
- **Deutsche Benutzeroberfläche** - Vollständig lokalisiert
- **Kundendateneingabe** - Name, Fahrzeugnummer und gewünschte Dienstleistung
- **Automatische Steuerberechnung** - MwSt 19% wird automatisch berechnet
- **Stammkundenrabatt** - 10% automatischer Rabatt nach 5 Besuchen
- **PDF-Rechnungsgenerierung** - Sofortiger Download professioneller Rechnungen
- **Glanzwerk-Branding** - Rechnungsdesign entspricht der Unternehmensidentität
- **Browserbasiert** - Funktioniert ohne Installation
- **Entwickler-Signatur** - Mazen Design Branding

### 🛠️ Technische Funktionen
- **Kundendatenbank** - SQLite-basierte Speicherung von Kundeninformationen
- **Besuchsverfolgung** - Automatische Verfolgung der Kundenbesuche für Rabatte
- **Responsive Design** - Funktioniert auf Desktop und mobilen Geräten
- **Moderne UI/UX** - Ansprechendes Design mit Animationen und Übergängen
- **Fehlerbehandlung** - Robuste Validierung und Fehlerbehandlung

## Technologie-Stack

### Backend
- **Programmiersprache:** Python 3.11
- **Framework:** Flask
- **PDF-Bibliothek:** fpdf2
- **Datenbank:** SQLite
- **CORS-Unterstützung:** Flask-CORS

### Frontend
- **HTML5** - Semantische Struktur
- **CSS3** - Moderne Styling mit Gradients und Animationen
- **JavaScript** - Interaktive Elemente (minimal)
- **Responsive Design** - Mobile-first Ansatz

### Deployment
- **Hosting:** Manus Cloud Platform
- **URL:** https://58hpi8c7n3dj.manus.space
- **Verfügbarkeit:** 24/7 öffentlich zugänglich

## Serviceangebot

### Verfügbare Dienstleistungen
1. **Grundreinigung** - 50,00€ (netto)
2. **Intensivreinigung** - 80,00€ (netto)
3. **Premium-Wäsche** - 120,00€ (netto)

### Preisberechnung
- **Nettobetrag:** Basispreis der gewählten Dienstleistung
- **MwSt (19%):** Automatisch berechnet und angezeigt
- **Bruttobetrag:** Netto + MwSt
- **Stammkundenrabatt:** 10% Rabatt nach 5 Besuchen
- **Endbetrag:** Brutto - Rabatt (falls anwendbar)

## Unternehmensinformationen

**Glanzwerk Rheinland**  
Krasnaer Str. 1  
56566 Neuwied  
Deutschland  

**Kontakt:**  
Telefon: +49 171 1858241  
E-Mail: Glanzwerk.Rheinland@gmail.com  
Website: glanzwerk-rheinland.de  

**Slogan:** "Grün gedacht, sauber gemacht"

## Benutzerhandbuch

### Rechnung erstellen
1. **Kundendaten eingeben**
   - Kundenname in das entsprechende Feld eingeben
   - Fahrzeugnummer/Kennzeichen eingeben (z.B. NR-AB 1234)

2. **Dienstleistung auswählen**
   - Aus dem Dropdown-Menü die gewünschte Dienstleistung wählen
   - Preise werden automatisch angezeigt

3. **Rechnung generieren**
   - Auf "Rechnung generieren" klicken
   - System berechnet automatisch alle Beträge
   - Rechnungsvorschau wird angezeigt

4. **PDF herunterladen**
   - Auf "PDF-Rechnung herunterladen" klicken
   - PDF wird automatisch generiert und heruntergeladen
   - Datei ist sofort druckbereit

### Stammkundenrabatt
- Das System verfolgt automatisch Kundenbesuche
- Nach dem 5. Besuch wird automatisch 10% Rabatt gewährt
- Rabatt wird deutlich in der Rechnung hervorgehoben
- Glückwunschnachricht wird angezeigt

## Technische Spezifikationen

### Datenbankschema
```sql
-- Kundentabelle
CREATE TABLE customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

-- Besuchstabelle
CREATE TABLE visits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    visit_date TEXT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);
```

### API-Endpunkte
- `GET /` - Hauptseite mit Eingabeformular
- `POST /generate_invoice` - Rechnungsgenerierung
- `GET /download_pdf` - PDF-Download

### PDF-Funktionen
- **Logo-Integration** - Glanzwerk-Logo im Header
- **Unternehmensdaten** - Vollständige Kontaktinformationen
- **Rechnungsdetails** - Eindeutige Rechnungsnummer und Datum
- **Kundendaten** - Name und Fahrzeuginformationen
- **Servicetabelle** - Detaillierte Aufschlüsselung der Kosten
- **Zahlungsinformationen** - Zahlungsbedingungen
- **Entwickler-Signatur** - Mazen Design Branding

## Sicherheit und Datenschutz

### Datensicherheit
- Lokale SQLite-Datenbank für Kundendaten
- Keine sensiblen Zahlungsinformationen gespeichert
- Session-basierte Datenübertragung für PDF-Generierung

### Datenschutz
- Minimale Datenerfassung (nur Name und Fahrzeugnummer)
- Keine persönlichen Identifikationsdaten erforderlich
- DSGVO-konform durch minimale Datenspeicherung

## Wartung und Support

### Systemanforderungen
- Moderner Webbrowser (Chrome, Firefox, Safari, Edge)
- Internetverbindung für Zugriff auf die Anwendung
- PDF-Reader für Rechnungsanzeige

### Backup und Wiederherstellung
- Automatische Datensicherung durch Cloud-Hosting
- Kundendatenbank wird persistent gespeichert
- Keine manuelle Wartung erforderlich

## Erweiterungsmöglichkeiten

### Geplante Funktionen
- **E-Mail-Integration** - Automatischer Rechnungsversand
- **WhatsApp-API** - Rechnungsversand über WhatsApp
- **Erweiterte Kundenverwaltung** - Detaillierte Kundenprofile
- **Rechnungshistorie** - Archiv aller generierten Rechnungen
- **Statistiken** - Umsatz- und Kundenanalysen
- **Multi-Standort-Unterstützung** - Für Franchise-Erweiterungen

### Skalierbarkeit
- Architektur unterstützt einfache Erweiterungen
- Modularer Aufbau ermöglicht neue Funktionen
- Cloud-basiertes Hosting für automatische Skalierung

## Projektentwicklung

### Entwicklungsphasen
1. **Projektanalyse und Planung** ✅
2. **Flask-Anwendung entwickeln** ✅
3. **PDF-Generierung implementieren** ✅
4. **Frontend-Interface erstellen** ✅
5. **Lokale Tests durchführen** ✅
6. **Anwendung bereitstellen** ✅

### Qualitätssicherung
- Umfassende Tests aller Funktionen
- Cross-Browser-Kompatibilität
- Mobile Responsivität
- PDF-Generierung mit verschiedenen Szenarien
- Stammkundenrabatt-Logik validiert

## Kontakt und Support

**Entwickler:** Mazen Design  
**Projekt-URL:** https://58hpi8c7n3dj.manus.space  
**Dokumentation:** Vollständig dokumentiert und getestet  
**Status:** Produktionsbereit und live verfügbar  

---

*Dieses Projekt wurde mit modernsten Webtechnologien entwickelt und ist sofort einsatzbereit für die Glanzwerk Rheinland Autowäscherei.*

